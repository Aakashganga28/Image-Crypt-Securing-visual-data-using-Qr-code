### QR-Code-Generator

Basically the Qr Code Generator Web Applicaton takes in input of any given text or Url and Converts into the QR Code Format

##Pure JavaScript and Simple CSS Side Project

##This Project is OpenSource SO Feel Free to Contribute

Website Deployment : https://qr-code-generator-free.netlify.app/

github pages Deployment : https://webdeveloperisaac.github.io/Qr-Code-Generator/

Initial UI
<br/>
<img src="./images/Initialsnap.png" height=300px/>
<br/>
After Load:
<br/>
<img src="./images/after%20generation.png" height=400px/>

##It Uses the QR-Generator-API and Feeds in the Image Asyncronously
Link : https://www.qr-code-generator.com


Support me on Patreon <br/>
[![Support me on Patreon](https://img.shields.io/endpoint.svg?url=https%3A%2F%2Fshieldsio-patreon.vercel.app%2Fapi%3Fusername%3Dwebdevisaac%26type%3Dpatrons&style=flat)](https://patreon.com/webdevisaac)

Always Open to Connect : https://webdevisaac.com
